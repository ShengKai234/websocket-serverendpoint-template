package com.signblast.websocketservice.payload.requestMessage;

import lombok.Data;

@Data
public class RequestMessage {
  String msg;
}

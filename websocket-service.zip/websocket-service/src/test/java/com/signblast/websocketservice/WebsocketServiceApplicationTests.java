package com.signblast.websocketservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebsocketServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
